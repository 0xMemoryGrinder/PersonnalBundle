#parse("C File Header.h")

#pragma once

#[[#include]]# <Polymorph/Components.hpp>
#[[#include]]# <Polymorph/Types.hpp>
#[[#include]]# <Polymorph/Factory.hpp>

namespace Polymorph
{
    class ${NAME}Script;
    class ${NAME}Initializer : public AComponentInitializer<${NAME}Script>
    {
///////////////////////////////// Constructors /////////////////////////////////

        public:
            ${NAME}Initializer(Config::XmlComponent &data, GameObject entity);

///////////////////////////--------------------------///////////////////////////



////////////////////////////////// Methods /////////////////////////////////////

        public:
            void build() final;

            void reference() final;
///////////////////////////--------------------------///////////////////////////
    };
}