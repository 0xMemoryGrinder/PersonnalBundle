/*
** EPITECH PROJECT, 2020
** TextRendererInitializer.cpp
** File description:
** TextRendererInitializer.cpp
*/

#[[#include]]# <Polymorph/Factory.hpp>
#[[#include]]# <Polymorph/Config.hpp>
#[[#include]]# "${NAME}Initializer.hpp"
#[[#include]]# "${NAME}Script.hpp"

namespace Polymorph
{
    ${NAME}Initializer::${NAME}Initializer(Config::XmlComponent &data, GameObject entity)
    : AComponentInitializer("${NAME}",data, entity) {}
    
    // Called at Script creation to set properties from configuration
    // use:  data.setProperty(yourScriptPropertyName, component->yourProperty)
    // optionnaly had a severity as third parameter to log when not found 
    // (Logger::severity, throw's when Logger::MAJOR)
    void ${NAME}Initializer::build()
    {
    }
    
    // Called after all components/scripts have been built
    void ${NAME}Initializer::reference()
    {
    
    }
}