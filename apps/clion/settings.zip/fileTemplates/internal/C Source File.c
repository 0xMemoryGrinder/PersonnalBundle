/*
** ${PROJECT_NAME}, ${YEAR}
** ${FILE_NAME} by 0xMemoryGrinder
*/

#if (${HEADER_FILENAME})
#[[#include]]# "${HEADER_FILENAME}"
#end
