#parse("C File Header.h")

#[[#include]]# #[[<]]#Polymorph/Core.hpp#[[>]]#
#[[#include]]# <Polymorph/Components.hpp>
#[[#include]]# "${NAME}Script.hpp"

namespace Polymorph
{
    ${NAME}Script::${NAME}Script(GameObject gameObject)
    : Component("${NAME}", gameObject) {}
    
    // Called only once when the Script is enabled the first time
    void ${NAME}Script::start()
    {
        
    }

    // Called every frame by the engine
    void ${NAME}Script::update()
    {
        
    }

}