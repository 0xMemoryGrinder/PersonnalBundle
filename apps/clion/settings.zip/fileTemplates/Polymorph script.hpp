#parse("C File Header.h")

#pragma once

#[[#include]]# <Polymorph/Components.hpp>
#[[#include]]# <Polymorph/Types.hpp>

namespace Polymorph
{
    class ${NAME}Script;
    using ${NAME} = safe_ptr<${NAME}Script>;
    using ${NAME}Base = std::shared_ptr<${NAME}Script>;

    class ${NAME}Script : public Component
    {
    
    ////////////////////// CONSTRUCTORS/DESTRUCTORS /////////////////////////
        public:
            explicit ${NAME}Script(GameObject gameObject);
    
    //////////////////////--------------------------/////////////////////////
    
    
    
    ///////////////////////////// PROPERTIES ////////////////////////////////
        public:
            
            
        private:
            
    //////////////////////--------------------------/////////////////////////
    
    
    
    /////////////////////////////// METHODS /////////////////////////////////
        public:
            void start() override;

            void update() override;
    
        private:
            
    //////////////////////--------------------------/////////////////////////
    
    };
}