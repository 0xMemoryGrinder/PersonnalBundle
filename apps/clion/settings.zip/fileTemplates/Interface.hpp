/*
** EPITECH PROJECT, 2022
** ${NAME}
** File description:
** Interface class
*/

#pragma once

#if( $Namespace != "" )
namespace ${Namespace}
{
#end
class ${NAME}
{

////////////////////// CONSTRUCTORS/DESTRUCTORS /////////////////////////

	public:
		virtual ~${NAME}();


//////////////////////--------------------------/////////////////////////



/////////////////////////////// METHODS /////////////////////////////////
	public:
	

	private:
		

//////////////////////--------------------------/////////////////////////

};
#if( $Namespace != "" )
}
#end
